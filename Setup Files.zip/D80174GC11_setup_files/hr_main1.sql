REM   Script:   hr_main1.sql
REM   Purpose:  To create users and initialise scripts that create schema objects.
REM   Created:  By Nagavalli Pataballa, on 16-MAR-2001 
REM   Modified by: Chaitanya Koratamaddi, 02/05/06		

REM   
--Please modify the path based on the location of the scripts.  

@@hr_cre.sql
@@hr_popul.sql
@@hr_idx.sql
@@hr_code.sql
@@hr_comnt.sql
@@dis_trigger.sql




